package RGU.MobAppDev.Adapters;

/*
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

//Java import for setting out crypto prices to five decimal places
import java.text.DecimalFormat;

//Java import for creating array lists
import java.util.ArrayList;

import RGU.MobAppDev.ClassesObjectCreation.Cryptocurrency;
import RGU.MobAppDev.R;

public class AdapterTop100Browser extends RecyclerView.Adapter<AdapterTop100Browser.CurrencyViewholder> {

    //Set to 5 decimal places
    private static DecimalFormat df2 = new DecimalFormat("#.#####");

    //Create ArrayList for list of top 100 cryptos that user can pretend to trade
    private ArrayList<Cryptocurrency> top100List;

    private Context context;

    //Constructor
    public AdapterTop100Browser(ArrayList<Cryptocurrency> cryptoList, Context context) {
        this.top100List = cryptoList;
        this.context = context;
    }

    public void filterList(ArrayList<Cryptocurrency> filterlist) {
        top100List = filterlist;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AdapterTop100Browser.CurrencyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.c_crypto_browser_card, parent, false);
        return new AdapterTop100Browser.CurrencyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterTop100Browser.CurrencyViewholder holder, int position) {

        Cryptocurrency modal = top100List.get(position);

        holder.nameTextView.setText(modal.getName());

        holder.priceTextView.setText("$ " + df2.format(modal.getPrice()));

        holder.tickerTextView.setText(modal.getTicker());
    }

    //Use overridden method to return the size of the list of cryptos
    //Not used and in any event always 100
    @Override
    public int getItemCount() {
        return top100List.size();
    }



   public class CurrencyViewholder extends RecyclerView.ViewHolder {

        private TextView tickerTextView, nameTextView, priceTextView;

        public CurrencyViewholder(@NonNull View itemView) {

            super(itemView);

            tickerTextView = itemView.findViewById(R.id.idTVAssetSymbol);
            nameTextView = itemView.findViewById(R.id.idTVAssetName);
            priceTextView = itemView.findViewById(R.id.idTVAssetPrice);
        }
    }
}


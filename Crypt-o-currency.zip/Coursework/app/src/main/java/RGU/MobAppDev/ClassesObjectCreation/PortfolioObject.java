package RGU.MobAppDev.ClassesObjectCreation;

/*
Author Robert Tunn, 2015065
Created 17 October 2022
Last modified 21 October 2022
 */

public class PortfolioObject {

    private String name;

    private String ticker;

    //Amount of crypto asset must be a double because fractions of 1 token/coin can be owned
    //e.g.1/32 of one Bitcoin
    //Note: Only integer amounts can be bought and sold as code stands owing to limits of EditText
    //in buy and sell pages
    private double amount;

    //Spot price is the instantaneous price of the crypto, also functions as sell price
    private double spotPrice;

    public PortfolioObject(String name, String ticker, double amount, double spotPrice) {
        this.ticker = ticker;
        this.name = name;
        this.amount = amount;
        this.spotPrice = spotPrice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getPrice() {
        return spotPrice;
    }

    public void setPrice(double price) {
        this.spotPrice = price;
    }

    public double getValue() {
        return amount*spotPrice;
    }
}

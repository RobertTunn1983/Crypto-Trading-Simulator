package RGU.MobAppDev.Pages;

/*
Navigation Page activity class
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 17 October 2022
 */

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import RGU.MobAppDev.ClassesObjectCreation.Cryptocurrency;
import RGU.MobAppDev.ClassesObjectCreation.Portfolio;
import RGU.MobAppDev.R;

public class NavigationPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.b_activity_navigation_page);

        //IMPORTANT: Run the API call within onCreate for the nav page so that there's an up to date
        //set of information on the cryptocurrencies before the user does anything
        //Price in a real crypto trading app would have to be instantaneous with the purchase/sale
        //but this is fast enough for a simulator
        fetchTop100Cryptocurrencies();
    }

    private void fetchTop100Cryptocurrencies() {

        //Metadata including logos
        //https://pro-api.coinmarketcap.com/v1/cryptocurrency/info?symbol=BTC&CMC_PRO_API_KEY=737eb4a8-1410-4f9a-8257-6b56d4bd67c8

        //Please note that logos used in the app are simply android alien heads because it was
        //not possible to get RecyclerView to automatically populate the logos with logo url's
        //In a real life scenario these would have to be stored as image files within the app

        //API call for prices on top100 cryptos
        String url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?limit=100&CMC_PRO_API_KEY=737eb4a8-1410-4f9a-8257-6b56d4bd67c8";

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                try {

                    JSONArray dataArray = response.getJSONArray("data");

                    for (int i = 0; i < dataArray.length(); i++) {

                        JSONObject dataObj = dataArray.getJSONObject(i);

                        String symbol = dataObj.getString("symbol");

                        String name = dataObj.getString("name");

                        String maxSupply = dataObj.getString("max_supply");

                        JSONObject quote = dataObj.getJSONObject("quote");

                        JSONObject USD = quote.getJSONObject("USD");

                        double price = USD.getDouble("price");

                        //These two are not required in the price browser rather crypto info page
                        //Simply pass them off as empty Strings so that ArrayList can be created
                        String logo = "";
                        String description = "";

                        //Add all top 100 cryptocurrencies to Portfolio.top100Cryptos ArrayList
                        Portfolio.top100Cryptos.add(new Cryptocurrency(name, symbol, maxSupply, logo, description, price));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

        queue.add(jsonObjectRequest);
    }


    //Navigate to welcome view
    public void backToWelcomeScreen(View view) {
        Intent switchActivityIntent = new Intent(this, WelcomePage.class);
        startActivity(switchActivityIntent);
    }


    //Navigate to CryptoBrowser view
    public void goToCryptoBrowser(View view) {
        Intent switchActivityIntent = new Intent(this, Top100CryptoBrowser.class);
        startActivity(switchActivityIntent);
    }


    //Navigate to Portfolio Page view
    public void goToPortfolioPage(View view) {
        Intent switchActivityIntent = new Intent(this, PortfolioPage.class);
        startActivity(switchActivityIntent);
    }
}
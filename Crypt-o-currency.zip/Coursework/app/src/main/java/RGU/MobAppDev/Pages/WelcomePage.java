package RGU.MobAppDev.Pages;

/*
Activity class for welcome page
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 17 October 2022
 */

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;

import RGU.MobAppDev.R;

public class WelcomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //Set first screen to be Main Activity
        setContentView(R.layout.a_activity_welcome);
    }

    //Move from welcome screen into app
    public void enterApp(View view) {
        Intent switchActivityIntent = new Intent(this, NavigationPage.class);
        startActivity(switchActivityIntent);
    }
}
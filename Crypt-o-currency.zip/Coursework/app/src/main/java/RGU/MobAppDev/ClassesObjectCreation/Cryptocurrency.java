package RGU.MobAppDev.ClassesObjectCreation;

/*
Public class for Cryptocurrency objects
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

public class Cryptocurrency {

    //Fields
    private String ticker;
    private String name;
    private String maxSupply;
    private String logo;
    private String description;
    private double price;

    //Constructor
    public Cryptocurrency(String name, String ticker, String maxSupply, String logo, String description, double price) {
        this.ticker = ticker;
        this.name = name;
        this.maxSupply = maxSupply;
        this.logo = logo;
        this.description = description;
        this.price = price;
    }



    //Getters
    public String getTicker() {
        return this.ticker;
    }

    public String getName() {
        return this.name;
    }

    public String getMaxSupply() {
        return this.maxSupply;
    }

    public String getLogo() {
        return this.logo;
    }

    public String getDescription() {
        return this.description;
    }

    public double getPrice() {
        return this.price;
    }



    //Setters - most not used
    public void setTicker(String inputTicker) {
        this.ticker = inputTicker;
    }

    public void setName(String inputName) {
        this.name = inputName;
    }

    public void setMaxSupply(String inputMaxSupply) {
        this.name = maxSupply;
    }

    public void setLogo(String inputLogo) {
        this.ticker = inputLogo;
    }

    public void setDescription(String inputDescription) {
        this.name = inputDescription;
    }

    public void setPrice(double inputPrice) {
        this.price = inputPrice;
    }
}




package RGU.MobAppDev.Adapters;

/*
Author Robert Tunn, 2015065
Created 21 October 2022
Last modified 21 October 2022
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.util.ArrayList;

import RGU.MobAppDev.ClassesObjectCreation.PortfolioObject;
import RGU.MobAppDev.R;

public class AdapterPortfolioPage extends RecyclerView.Adapter<AdapterPortfolioPage.PortfolioViewholder> {

    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private static DecimalFormat df5 = new DecimalFormat("#.#####");

    private ArrayList<PortfolioObject> portfolioObjectList;

    private Context context;

    public AdapterPortfolioPage(ArrayList<PortfolioObject> portfolioObjectList, Context context) {
        this.portfolioObjectList = portfolioObjectList;
        this.context = context;
    }

    @NonNull
    @Override
    public AdapterPortfolioPage.PortfolioViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.e_portfolio_card, parent, false);
        return new AdapterPortfolioPage.PortfolioViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterPortfolioPage.PortfolioViewholder holder, int position) {

        PortfolioObject modal = portfolioObjectList.get(position);

        //Name
        holder.tv1.setText(modal.getName());

        //Symbol
        holder.tv2.setText(modal.getTicker());

        //Numerical data
        holder.tv3.setText("$ " + df5.format(modal.getPrice()));
        holder.tv4.setText(df5.format(modal.getAmount()));
        holder.tv5.setText("$ " + df2.format(modal.getValue()));
    }

    @Override
    public int getItemCount() {
        return portfolioObjectList.size();
    }

    public class PortfolioViewholder extends RecyclerView.ViewHolder {

        private TextView tv1, tv2, tv3, tv4, tv5;

        public PortfolioViewholder(@NonNull View itemView) {

            super(itemView);

            //Headers
            tv1 = itemView.findViewById(R.id.idTVAssetName);
            tv2 = itemView.findViewById(R.id.idTVAssetSymbol);

            //Numerical values
            tv3 = itemView.findViewById(R.id.idTVAssetPriceNum);
            tv4 = itemView.findViewById(R.id.idTVQuantityNum);
            tv5 = itemView.findViewById(R.id.idTVAssetValueNum);
        }
    }
}


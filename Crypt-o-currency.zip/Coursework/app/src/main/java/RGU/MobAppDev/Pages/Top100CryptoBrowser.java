package RGU.MobAppDev.Pages;

/*
Activity class for top 20 Cryptocurrencies by Market Cap
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import RGU.MobAppDev.Adapters.AdapterTop100Browser;
import RGU.MobAppDev.ClassesObjectCreation.Cryptocurrency;
import RGU.MobAppDev.ClassesObjectCreation.Portfolio;
import RGU.MobAppDev.R;

public class Top100CryptoBrowser extends AppCompatActivity {

    private RecyclerView currencyRV;
    private EditText searchEdt;
    private AdapterTop100Browser currencyRVAdapter;
    private ProgressBar loadingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.c_crypto_browser_page);

        searchEdt = findViewById(R.id.idEdtCrypto);

        // initializing all our variables and array list.
        loadingPB = findViewById(R.id.idPBLoading);
        currencyRV = findViewById(R.id.assets);

        currencyRVAdapter = new AdapterTop100Browser(Portfolio.top100Cryptos, this);
        currencyRV.setLayoutManager(new LinearLayoutManager(this));
        currencyRV.setAdapter(currencyRVAdapter);

        fetchTop100Cryptocurrencies();

        searchEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
    }

    private void filter(String filter) {

        ArrayList<Cryptocurrency> filteredlist = new ArrayList<>();
        ArrayList<Cryptocurrency> cropped_list = new ArrayList<>();

        for (Cryptocurrency item : Portfolio.top100Cryptos) {
            if (item.getName().toLowerCase().contains(filter.toLowerCase())) {
                filteredlist.add(item);
            }
        }

        if (filteredlist.isEmpty()) {
            Toast.makeText(this, "Currency not found..", Toast.LENGTH_SHORT).show();
        } else {
            cropped_list.add(filteredlist.get(0));
            currencyRVAdapter.filterList(cropped_list);
        }
    }

    //API call
    private void fetchTop100Cryptocurrencies() {

        //Metadata including logos
        //https://pro-api.coinmarketcap.com/v1/cryptocurrency/info?symbol=BTC&CMC_PRO_API_KEY=737eb4a8-1410-4f9a-8257-6b56d4bd67c8

        String url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest?limit=100&CMC_PRO_API_KEY=737eb4a8-1410-4f9a-8257-6b56d4bd67c8";

        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                loadingPB.setVisibility(View.GONE);

                try {

                    JSONArray dataArray = response.getJSONArray("data");

                    for (int i = 0; i < dataArray.length(); i++) {

                        JSONObject dataObj = dataArray.getJSONObject(i);

                        String symbol = dataObj.getString("symbol");

                        String name = dataObj.getString("name");

                        String maxSupply = dataObj.getString("max_supply");

                        JSONObject quote = dataObj.getJSONObject("quote");

                        JSONObject USD = quote.getJSONObject("USD");

                        double price = USD.getDouble("price");

                        //These two are not required in the price browser
                        //Simply pass them off as empty Strings so that ArrayList can be created
                        String logo = "";
                        String description = "";

                        // adding all data to our array list.
                        Portfolio.top100Cryptos.add(new Cryptocurrency(name, symbol, maxSupply, logo, description, price));

                    }
                    // notifying adapter on data change.
                    currencyRVAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Top100CryptoBrowser.this, "Error1!", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Top100CryptoBrowser.this, "Error2!", Toast.LENGTH_SHORT).show();
            }
        });

        queue.add(jsonObjectRequest);
    }

    //Navigate to Navigation Page view
    public void goToNavigationPage(View view) {
        Intent switchActivityIntent = new Intent(this, NavigationPage.class);
        startActivity(switchActivityIntent);
    }
}
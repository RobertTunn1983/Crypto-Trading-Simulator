package RGU.MobAppDev.Adapters;

/*
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import RGU.MobAppDev.ClassesObjectCreation.Cryptocurrency;

import RGU.MobAppDev.R;

public class AdapterInfoPage extends RecyclerView.Adapter<AdapterInfoPage.CurrencyViewholder> {

    private ArrayList<Cryptocurrency> cryptoList;

    private Context context;

    public AdapterInfoPage(ArrayList<Cryptocurrency> cryptoList, Context context) {
        this.cryptoList = cryptoList;
        this.context = context;
    }

    public void filterList(ArrayList<Cryptocurrency> filterlist) {
        cryptoList = filterlist;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public AdapterInfoPage.CurrencyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.d_crypto_info_card, parent, false);
        return new AdapterInfoPage.CurrencyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterInfoPage.CurrencyViewholder holder, int position) {

        Cryptocurrency modal = cryptoList.get(position);

        holder.nameTV.setText(modal.getName());

        holder.descriptionTV.setText(modal.getDescription());

    }

    //Use overridden method to return the size of the list of cryptos - not actually used in final version
    @Override
    public int getItemCount() {
        return cryptoList.size();
    }


    public class CurrencyViewholder extends RecyclerView.ViewHolder {

        private TextView nameTV, descriptionTV;

        public CurrencyViewholder(@NonNull View itemView) {

            super(itemView);

            nameTV = itemView.findViewById(R.id.idTVInfoName);
            descriptionTV = itemView.findViewById(R.id.idTVInfoDescription);
        }
    }
}


package RGU.MobAppDev.ClassesObjectCreation;

/*
Class to store details for the top 100 cryptocurrencies from CoinMarketCap API call and
the user's portfolio
Author Robert Tunn, 2015065
Created 21 October 2022
Created 21 October 2022
Last modified 28 October 2022
 */

import java.util.ArrayList;

public class Portfolio {

    //ArrayList containing information of top 100 cryptocurrencies for spot price browser
    public static ArrayList<Cryptocurrency> top100Cryptos = new ArrayList<>();

    //ArrayList containing info on top 100 cryptocurrencies
    public static ArrayList<Cryptocurrency> cryptoInfoList = new ArrayList<>();

    //ArrayList of items user currently has in their Portfolio
    public static ArrayList<PortfolioObject> portfolioItems = new ArrayList<>();

    //Self explanatory variables
    public static double portfolioValue = 0.00;
    public static double totalTransFeesIncurred = 0.00;

    //Starting balance is $100,000 do this by making amount left to invest equal 100k at beginning
    public static double amountLeftToInvest = 100000.00;
}



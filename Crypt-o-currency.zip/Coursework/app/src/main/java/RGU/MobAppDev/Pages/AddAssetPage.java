/*
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

package RGU.MobAppDev.Pages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import RGU.MobAppDev.ClassesObjectCreation.Cryptocurrency;
import RGU.MobAppDev.ClassesObjectCreation.Portfolio;
import RGU.MobAppDev.ClassesObjectCreation.PortfolioObject;
import RGU.MobAppDev.R;

public class AddAssetPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.f_add_asset_page);

        //Set up spinner
        Spinner spinner = findViewById(R.id.spinnerAdd);

        //Create ArrayList<String> to populate spinner
        ArrayList<String> spinnerList = new ArrayList<>();

        //Populate ArrayList<String> using getName for all portfolioItems
        spinnerList = populateSpinnerAdd(Portfolio.top100Cryptos);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, spinnerList);

        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String assetName = parent.getItemAtPosition(position).toString();
                Toast.makeText(parent.getContext(), "Selected: "
                        + assetName, Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView <?> parent) {
            }
        });

        //Set up number input EditText box
        EditText quantEnter = findViewById(R.id.editTextNumber);

        //Add asset button
        Button confirmAddAssetButton = findViewById(R.id.confirmAddAssetButton);

        //textView
        TextView descTransaction = findViewById(R.id.descTransaction);

        //Click on add asset button and asset is added
        confirmAddAssetButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                //Grab cryptocurrency name from spinner
                String cryptoName = spinner.getSelectedItem().toString();

                //Grab amount from EditText box and return as a Double to 5 decimal places
                double amountDoub = Double.parseDouble(quantEnter.getText().toString());

                //Get instantaneous tracker and spot price from top100Cryptos ArrayList
                String ticker = "";
                double spotPrice = 0.00;

                for (int i = 0; i < Portfolio.top100Cryptos.size(); i++) {

                    String currentName = Portfolio.top100Cryptos.get(i).getName();

                    if (currentName == cryptoName) {
                        ticker = Portfolio.top100Cryptos.get(i).getTicker();
                        spotPrice = Portfolio.top100Cryptos.get(i).getPrice();
                    }
                }

                //Prevent user from overspending their balance
                //Total cost of transaction
                //For now assume 3 per cent for transaction fees because I don't want to pay
                //an exhorbitant sum for the full CoinMarketCap API subscription
                //Coingecko API could have given me these things for free but they wanted money
                //for other basic features which are used here
                double transFees = (amountDoub * spotPrice) * 0.03;
                double costOfCrypto = amountDoub * spotPrice;
                double totalCost = ((amountDoub * spotPrice) + transFees);

                /*
                //Not enough room for this on the emulator even though it would have been good to
                //see laid out in full
                "You have added " + "$" + amountDoub + " tokens/ coins of "
                        + cryptoName + " at a total cost of $" + costOfCrypto +
                        " to your portfolio. You now have a total of $" + balanceString +
                        " left to invest. In a real world scenario the total cost would have " +
                        "been $" + totalCost + " which includes transaction fees at $"
                        + transFees
                */

                //If total cost of crypto is less than amount left to invest...
                if (totalCost <= Portfolio.amountLeftToInvest) {
                    //...add the items to the portfolio
                    Portfolio.portfolioItems.add
                            (new PortfolioObject(cryptoName, ticker, amountDoub, spotPrice));

                    //Let user know purchase is successful
                    descTransaction.setText("Portfolio updated!");

                    //Add spot value of crypto asset to portfolio value
                    Portfolio.portfolioValue += costOfCrypto;

                    //Take a tab of total transaction fees incurred
                    //Note: again owing to my reluctance to pay a fortune for information I am unable
                    //to incorporate the real world transaction fees into the formula but this could
                    //easily be done
                    Portfolio.totalTransFeesIncurred += transFees;

                    //Keep a tab of amount of money left to invest
                    double holderALTI;
                    holderALTI = Portfolio.amountLeftToInvest;
                    holderALTI -= totalCost;
                    Portfolio.amountLeftToInvest = holderALTI;

                //If the amount left to invest is less than cost of purchase...
                } else {
                    //...do not allow the purchase to go ahead
                    descTransaction.setText("You do not have enough on your account to complete" +
                            " this transaction!");
                }

                //Reset Spinner and Edittext
                spinner.setSelection(0);
                quantEnter.getText().clear();
            }
        });
    }

    //Use getName function within Cryptocurrency class to populate spinner
    public ArrayList<String> populateSpinnerAdd(ArrayList<Cryptocurrency> inputArrayList) {

        ArrayList<String> outputArrayList = new ArrayList<>();

        for (int i = 0; i < inputArrayList.size(); i++) {
            outputArrayList.add(inputArrayList.get(i).getName());
        }

        return outputArrayList;
    }



    public void goToPortfolioPage(View view) {
        Intent switchActivityIntent = new Intent(this, PortfolioPage.class);
        startActivity(switchActivityIntent);
    }
}
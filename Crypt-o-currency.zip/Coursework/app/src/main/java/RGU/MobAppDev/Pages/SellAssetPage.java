/*
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

package RGU.MobAppDev.Pages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import RGU.MobAppDev.ClassesObjectCreation.Portfolio;
import RGU.MobAppDev.ClassesObjectCreation.PortfolioObject;
import RGU.MobAppDev.R;


//Code very similar to add asset page
public class SellAssetPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.g_sell_asset_page);

        //Set up spinner
        Spinner spinner = findViewById(R.id.spinnerSell);

        //Create ArrayList<String> to populate spinner
        ArrayList<String> spinnerList = new ArrayList<>();

        spinnerList = populateSpinnerSell(Portfolio.portfolioItems);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, spinnerList);

        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String assetName = parent.getItemAtPosition(position).toString();
                Toast.makeText(parent.getContext(), "Selected: "
                        + assetName, Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView <?> parent) {
            }
        });

        EditText quantEnter2 = findViewById(R.id.editTextNumber2);

        Button confirmSellAssetButton = findViewById(R.id.confirmSellAssetButton);

        TextView descTransaction2 = findViewById(R.id.descTransaction2);

        confirmSellAssetButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                //Grab cryptocurrency name from spinner
                String cryptoName = spinner.getSelectedItem().toString();

                //Grab amount from EditText box and return as a Double to 5 decimal places
                double amountToBeSold = Double.parseDouble(quantEnter2.getText().toString());

                //Get instantaneous tracker and spot price from top100Cryptos ArrayList
                String ticker = "";
                double spotPrice = 0.00;

                //IMPORTANT!!!: Spot price must come from the top100Cryptos ArrayList to get an up to date sale price
                //Again this is not as up to date as it would be in a crypto trading app but good
                //enough for a simulator
                for (int i = 0; i < Portfolio.top100Cryptos.size(); i++) {

                    String currentNameFind = Portfolio.top100Cryptos.get(i).getName();

                    if (currentNameFind == cryptoName) {
                        ticker = Portfolio.top100Cryptos.get(i).getTicker();
                        spotPrice = Portfolio.top100Cryptos.get(i).getPrice();
                    }
                }

                //Sell item - remove from Portfolio.portfolioItems static var and deal with
                //proceeds of sale
                for (int i = 0; i < Portfolio.portfolioItems.size(); i++) {

                    String currentNameRemove = Portfolio.portfolioItems.get(i).getName();
                    double quantOwned = Portfolio.portfolioItems.get(i).getAmount();

                    String test = "Portfolio updated";

                    //Find the type of cryptocurrency to be sold...
                    //...make sure that at least that amount is owned...
                    if (currentNameRemove == cryptoName && quantOwned >= amountToBeSold) {

                        //...then remove from portfolio
                        Portfolio.portfolioItems.remove(i);
                        descTransaction2.setText(test);

                    } else {
                        //Otherwise do not allow the transaction to go ahead
                        descTransaction2.setText("Not possible, you don't own this amount to sell!");
                    }

                    //Code above prevents more shares being sold than exist in portfolio but
                    //must also deal with the situation where part of the holding e.g. half of the
                    //Bitcoin is sold off and half is retained...

                    if(quantOwned > amountToBeSold) {
                        double difference = quantOwned - amountToBeSold;
                        Portfolio.portfolioItems.add(new PortfolioObject(cryptoName, ticker, difference, spotPrice));
                    }

                    //Cannot get decimal point to work in input box for sale amount
                    //Stuck to integer values for sale amounts!!!!
                }

                //...before tending to the accounting
                //Remove market value of cryptocurrency from portfolio value
                //Work in transaction fee
                double displayPortfolioValue = Portfolio.portfolioValue;
                displayPortfolioValue = displayPortfolioValue - (spotPrice*amountToBeSold);
                Portfolio.portfolioValue = displayPortfolioValue;

                //Update balance of money left to invest
                //Note "self-referential" static variables crash the system e.g.
                //Portfolio.amountLeftToInvest = Portfolio.amountLeftToInvest + spotPrice does not work!

                //Hence the clumsy arrangement 
                double displayALTI = Portfolio.amountLeftToInvest;
                Portfolio.amountLeftToInvest = Portfolio.amountLeftToInvest + (spotPrice*amountToBeSold);

            }
        });
    }

    public ArrayList<PortfolioObject> mergeDuplicates (ArrayList<PortfolioObject> inputAL){

        ArrayList<PortfolioObject> outputArrayList = new ArrayList<>();

        for (int a = 0; a < inputAL.size(); a++){

            String name = inputAL.get(a).getName();
            String ticker = inputAL.get(a).getTicker();
            double amount = inputAL.get(a).getAmount();
            double spotPrice = inputAL.get(a).getPrice();

            for (int b = (a+1); b < (inputAL.size()-1); b++) {

                String name2 = inputAL.get(b).getName();
                double amount2 = inputAL.get(b).getAmount();

                double newAmount = amount + amount2;

                if(name == name2) {
                    outputArrayList.add(new PortfolioObject(name, ticker, newAmount, spotPrice));
                }
            }
        }
        return outputArrayList;
    }

    public ArrayList<String> populateSpinnerSell(ArrayList<PortfolioObject> inputArrayList) {

        ArrayList<String> outputArrayList = new ArrayList<>();

        if (inputArrayList.size() == 0) {
            outputArrayList.add("You currently have no assets");
        } else {
            for (int i = 0; i < inputArrayList.size(); i++) {
                outputArrayList.add(inputArrayList.get(i).getName());
            }
        }
        return outputArrayList;
    }

    //Move from welcome screen into app
    public void goToPortfolioPage(View view) {
        Intent switchActivityIntent = new Intent(this, PortfolioPage.class);
        startActivity(switchActivityIntent);
    }
}
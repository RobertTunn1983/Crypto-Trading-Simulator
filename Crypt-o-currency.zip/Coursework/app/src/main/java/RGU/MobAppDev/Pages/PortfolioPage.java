package RGU.MobAppDev.Pages;

/*
Activity class for top 20 Cryptocurrencies by Market Cap
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import RGU.MobAppDev.ClassesObjectCreation.Portfolio;
import RGU.MobAppDev.R;

import RGU.MobAppDev.Adapters.AdapterPortfolioPage;

public class PortfolioPage extends AppCompatActivity {

    private RecyclerView portfolioRV;
    public static AdapterPortfolioPage portfolioRVAdapter;
    private ProgressBar loadingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.e_portfolio_page);

        TextView top = findViewById(R.id.top);
        TextView middle = findViewById(R.id.middle);
        TextView bottom = findViewById(R.id.bottom);

        top.setText("$" + String.format("%.2f", Portfolio.portfolioValue));
        middle.setText("$" + String.format("%.2f", Portfolio.amountLeftToInvest));
        bottom.setText("$" + String.format("%.2f", Portfolio.totalTransFeesIncurred));

        loadingPB = findViewById(R.id.idPBLoading);
        portfolioRV = findViewById(R.id.assets);
        portfolioRVAdapter = new AdapterPortfolioPage(Portfolio.portfolioItems, this);
        portfolioRV.setLayoutManager(new LinearLayoutManager(this));
        portfolioRV.setAdapter(portfolioRVAdapter);
    }

    //Navigate to Navigation Page view
    public void goToNavigationPage(View view) {
        Intent switchActivityIntent = new Intent(this, NavigationPage.class);
        startActivity(switchActivityIntent);
    }

    //Move from welcome screen into app
    public void goToAddAssetPage(View view) {
        Intent switchActivityIntent = new Intent(this, AddAssetPage.class);
        startActivity(switchActivityIntent);
    }

    //Move from welcome screen into app
    public void goToSellAssetPage(View view) {
        Intent switchActivityIntent = new Intent(this, SellAssetPage.class);
        startActivity(switchActivityIntent);
    }
}
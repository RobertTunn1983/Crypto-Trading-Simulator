package RGU.MobAppDev.Pages;

/*
Author Robert Tunn, 2015065
Created 11 October 2022
Last modified 03 December 2022
 */

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import RGU.MobAppDev.Adapters.AdapterInfoPage;
import RGU.MobAppDev.ClassesObjectCreation.Cryptocurrency;
import RGU.MobAppDev.ClassesObjectCreation.Portfolio;
import RGU.MobAppDev.R;

public class CryptoInfo extends AppCompatActivity {

    private RecyclerView currencyRV;
    private EditText searchEdt;
    private AdapterInfoPage currencyRVAdapter;
    private ProgressBar loadingPB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.d_crypto_info_page);

        searchEdt = findViewById(R.id.idEdtCrypto2);

        loadingPB = findViewById(R.id.idPBLoading2);
        currencyRV = findViewById(R.id.cryptocurrencies2);

        currencyRVAdapter = new AdapterInfoPage(Portfolio.cryptoInfoList, this);
        currencyRV.setLayoutManager(new LinearLayoutManager(this));
        currencyRV.setAdapter(currencyRVAdapter);

        populateCryptoInfoList();

        searchEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
    }

    private void filter(String filter) {

        ArrayList<Cryptocurrency> filteredlist = new ArrayList<>();
        ArrayList<Cryptocurrency> clipped_list = new ArrayList<>();

        for (Cryptocurrency item : Portfolio.cryptoInfoList) {
            if (item.getName().toLowerCase().contains(filter.toLowerCase())) {
                filteredlist.add(item);
            }
        }
        if (filteredlist.isEmpty()) {
            Toast.makeText(this, "No currency found..", Toast.LENGTH_SHORT).show();
        } else {
            clipped_list.add(filteredlist.get(0));
            currencyRVAdapter.filterList(clipped_list);
        }
    }

    private void populateCryptoInfoList() {

        //This is only an example of what could be loaded otherwise the list gets out of hand for the
        //purposes of a coursework

        String url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/info?symbol=BTC,ETH,USDT,USDC,BNB,XRP,BUSD,ADA,SOL,DOGE,ENJ&CMC_PRO_API_KEY=737eb4a8-1410-4f9a-8257-6b56d4bd67c8";
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {

                loadingPB.setVisibility(View.GONE);

                try {

                    JSONObject data = response.getJSONObject("data");

                    JSONObject bitcoin      = data.getJSONObject("BTC");
                    JSONObject ethereum     = data.getJSONObject("ETH");
                    JSONObject tether       = data.getJSONObject("USDT");
                    JSONObject usdcoin      = data.getJSONObject("USDC");
                    JSONObject binance      = data.getJSONObject("BNB");
                    JSONObject XRP          = data.getJSONObject("XRP");
                    JSONObject BUSD         = data.getJSONObject("BUSD");
                    JSONObject cardano      = data.getJSONObject("ADA");
                    JSONObject sol          = data.getJSONObject("SOL");
                    JSONObject doge         = data.getJSONObject("DOGE");
                    JSONObject ENJIN_COIN   = data.getJSONObject("ENJ");

                    //These two are not required for the information page because this information
                    //is contained within the description
                    String maxSupply = "empty";
                    double price = 0.00;

                    String nameBitcoin = bitcoin.getString("name");
                    String symbolBitcoin = bitcoin.getString("symbol");
                    String logoBitcoin = bitcoin.getString("logo");
                    String descriptionBitcoin = bitcoin.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameBitcoin, symbolBitcoin, maxSupply, logoBitcoin, descriptionBitcoin, price));

                    String nameEthereum = ethereum.getString("name");
                    String symbolEthereum = ethereum.getString("symbol");
                    String logoEthereum = ethereum.getString("logo");
                    String descriptionEthereum = ethereum.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameEthereum,symbolEthereum, maxSupply, logoEthereum, descriptionEthereum, price));

                    String nameTether = tether.getString("name");
                    String symbolTether = tether.getString("symbol");
                    String logoTether = tether.getString("logo");
                    String descriptionTether = tether.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameTether,symbolTether, maxSupply, logoTether, descriptionTether, price));

                    String nameUSDC = usdcoin.getString("name");
                    String symbolUSDC = usdcoin.getString("symbol");
                    String logoUSDC = usdcoin.getString("logo");
                    String descriptionUSDC = usdcoin.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameUSDC,symbolUSDC, maxSupply, logoUSDC, descriptionUSDC, price));

                    String nameBinance = binance.getString("name");
                    String symbolBinance = binance.getString("symbol");
                    String logoBinance = binance.getString("logo");
                    String descriptionBinance = binance.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameBinance, symbolBinance, maxSupply, logoBinance, descriptionBinance, price));

                    String nameXRP = XRP.getString("name");
                    String symbolXRP = XRP.getString("symbol");
                    String logoXRP = XRP.getString("logo");
                    String descriptionXRP = XRP.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameXRP, symbolXRP, maxSupply, logoXRP, descriptionXRP, price));

                    String nameBUSD = BUSD.getString("name");
                    String symbolBUSD = BUSD.getString("symbol");
                    String logoBUSD = BUSD.getString("logo");
                    String descriptionBUSD = BUSD.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameBUSD, symbolBUSD, maxSupply, logoBUSD, descriptionBUSD, price));

                    String nameCardano = cardano.getString("name");
                    String symbolCardano = cardano.getString("symbol");
                    String logoCardano = cardano.getString("logo");
                    String descriptionCardano = cardano.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameCardano, symbolCardano, maxSupply, logoCardano, descriptionCardano, price));

                    String nameSol = sol.getString("name");
                    String symbolSol = sol.getString("symbol");
                    String logoSol = sol.getString("logo");
                    String descriptionSol = sol.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameSol, symbolSol, maxSupply, logoSol, descriptionSol, price));

                    String nameDoge = doge.getString("name");
                    String symbolDoge = doge.getString("symbol");
                    String logoDoge = doge.getString("logo");
                    String descriptionDoge = doge.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameDoge, symbolDoge, maxSupply, logoDoge, descriptionDoge, price));

                    String nameENJIN = ENJIN_COIN.getString("name");
                    String symbolENJIN = ENJIN_COIN.getString("symbol");
                    String logoENJIN = ENJIN_COIN.getString("logo");
                    String descriptionENJIN = ENJIN_COIN.getString("description");

                    Portfolio.cryptoInfoList.add(new Cryptocurrency(nameENJIN, symbolENJIN, maxSupply, logoENJIN, descriptionENJIN, price));

                    currencyRVAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    //This should never call
                    e.printStackTrace();
                    Toast.makeText(CryptoInfo.this, "Error1!", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                //This should never call
                Toast.makeText(CryptoInfo.this, "Error2!", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonObjectRequest);
    }


    //Navigate to Navigation Page view
    public void goToNavigationPage(View view) {
        Intent switchActivityIntent = new Intent(this, NavigationPage.class);
        startActivity(switchActivityIntent);
    }
}